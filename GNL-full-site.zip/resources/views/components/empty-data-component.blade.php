<!-- resources/views/components/empty-data-component.blade.php -->

<div class="text-center d-flex justify-content-center align-items-center flex-column" style="min-height: 50vh;">
    <i class="fa-solid fa-circle-exclamation" style="font-size: 2rem; color:#E03137;"></i>
    <h6 style="font-size: 1rem; font-weight: 700;" class="mt-3">{{ $dynamicData }}</h6>
</div>