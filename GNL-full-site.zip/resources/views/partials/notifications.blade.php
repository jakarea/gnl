<div class="notify-list-box custom-scroll-bar" id="notifyList">
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/primary.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>New Project Added</h5>
        <div class="d_flex">
          <p>New project added successfully</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/primary.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>Marketing Service Added</h5>
        <div class="d_flex">
          <p>New marketing service added</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/secondary.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>New Task Added</h5>
        <div class="d_flex">
          <p>XYZ Tech posted new job for ui ux designer</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/danger.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>New Job Alert</h5>
        <div class="d_flex">
          <p>New task added successfully</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/danger.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>New Job Alert</h5>
        <div class="d_flex">
          <p>Marketing Service Updated</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/secondary.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>New Project Added</h5>
        <div class="d_flex">
          <p>New project added successfully</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/danger.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>New Job Alert</h5>
        <div class="d_flex">
          <p>Marketing Service Updated</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
    <!-- item -->
    <div class="media">
      <img src="{{ asset('assets/images/icons/secondary.svg') }}" alt="I" class="fluid">
      <div class="media-body">
        <h5>New Project Added</h5>
        <div class="d_flex">
          <p>New project added successfully</p>
          <span>11 Oct, 2023</span>
        </div>

      </div>
    </div>
    <!-- item -->
  </div>